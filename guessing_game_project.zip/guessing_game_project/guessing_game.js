const readline = require("readline")

const askGuess = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})
let secretNumber = 0;
number_of_attempt = 0

function askRange(){
    askGuess.question("Enter a min range: ", first_answer=>{
        askGuess.question("Enter max range: ", second_answer=>{
            askGuess.question("Enter number of attempt: ",attempt=>{
                number_of_attempt = Number(attempt)
                secretNumber = randomRange(Number(first_answer), Number(second_answer))
                console.log(`I think of a number between ${first_answer} and ${second_answer}`)
                prompt()
            })
           
        })
    })
}
let key = false
function randomRange(min, max){
    return Math.floor(Math.random() * (max - min) + min)
}

function prompt(){
    askGuess.question("Enter a guess: ", answer=>{
        key = checkGuess(Number(answer))
        if (!key){
            number_of_attempt -= 1
            prompt()
        }else{
            askGuess.close()
        }
        if(number_of_attempt == 0){
            askGuess.close()
            console.log("You loose!")
        }
    })

}

function checkGuess(number){
    if (number > secretNumber){
        console.log("Too High")
        return false
    }
    else if(number < secretNumber){
        console.log("Too Low")
        return false
    }
    else if (number == secretNumber){
        console.log("Correct: You win")
        return true
    }
}
askRange()