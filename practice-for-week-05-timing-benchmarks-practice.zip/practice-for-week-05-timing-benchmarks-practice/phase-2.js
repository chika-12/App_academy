const [addNums, addManyNums] = require("./phase-1");

// Runs `addNums` in 10 increasing increments
function addNums10(increment) {
  let arr = []
  for(let index = increment; index <= increment * 10; index += increment){
    arr.push(addNums(index))
  }
  return arr
  // Fill this in

}

// Runs `addManyNums` in 10 increasing increments
function addManyNums10(increment) {
  let arr = [];
  for(let index = increment; index <= increment * 10; index += increment){
    arr.push(addManyNums(index))
  }
  return arr
  // Fill this in

}

module.exports = [addNums10, addManyNums10];