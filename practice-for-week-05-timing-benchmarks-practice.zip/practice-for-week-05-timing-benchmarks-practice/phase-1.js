// Adds up positive integers from 1-n
function addNums(n) {
  let sum = 0;
  for(let index = 1; index <= n; index += 1){
    sum += index
  }
  return sum  // Fill this in

}


// Adds up values of addNums(1) through addNums(n)
function addManyNums(n) {
  // Fill this in
  let sum = 0;
  for(let val = 1 ; val <= n; val += 1){
    sum += addNums(val);
  }
  return sum
}



module.exports = [addNums, addManyNums];