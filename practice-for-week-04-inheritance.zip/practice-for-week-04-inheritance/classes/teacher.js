const Person = require('./person');

class Teacher extends Person{
  constructor(firstName, lastName,subject, yearsOfExperience){
    super(firstName, lastName)
    this.subject = subject;
    this.yearsOfExperience = yearsOfExperience
  }
  static combinedYearsOfExperience(teachers){
    let experience = teachers.reduce((sum, teacher)=> sum + teacher.yearsOfExperience, 0)
    return experience
  }
}
const mark = new Teacher("Mark", "Mercy", 23, "Chemistry", 8)
const main = new Teacher("Peter", "Joshua", 45, "Physics", 9)
const arr = [mark, main]
console.log(Teacher.combinedYearsOfExperience(arr))
// Your code here

/****************************************************************************/
/******************* DO NOT EDIT CODE BELOW THIS LINE ***********************/

try {
  module.exports = Teacher;
} catch {
  module.exports = null;
}