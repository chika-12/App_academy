const Person = require('./person');

class Student extends Person{
  constructor(firstName, lastName, major, GPA){
    super(firstName, lastName)
    this.major = major
    this.GPA = GPA
  }
  static compareGPA(std1, std2){
    if (std1.GPA > std2.GPA){
      return `${std1.firstName} ${std1.lastName} has the higher GPA.`
    }else if (std1.GPA < std2.GPA){
      return `${std2.firstName} ${std2.lastName} has the higher GPA.`
    }else if (std1.GPA == std2.GPA){
      return "Both students have the same GPA"
    }
  }
}
const firstStd = new Student("Chika", "Mark", 23, "Maths", 4.5)
const secondStd = new Student("Faith", "Mercy", 14, "English", 4.5)
console.log(Student.compareGPA(firstStd, secondStd))
// Your code here

/****************************************************************************/
/******************* DO NOT EDIT CODE BELOW THIS LINE ***********************/

try {
  module.exports = Student;
} catch {
  module.exports = null;
}