class Dog {
  constructor({ name, color, age, description }) {
    this.name = name;
    this.color = color;
    this.age = age;
    this.description = description;
  }
}

module.exports = Dog;
