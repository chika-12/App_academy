// Your code here
class Person{
  constructor(firstName, lastName, age){
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
  }
  introduce(){
    console.log(`Hi, I'm ${this.firstName} ${this.lastName} and I'm ${this.age} years old`);
  }
  static introducePeople(persons){
    try {
      if (!Array.isArray(persons)){
        throw new Error("introducePeople only takes an array as an argument.")
      }
    }catch(error){
      console.log(error.message)
      return
    }
    for (let index = 0; index < persons.length; index++){
      if (persons[index] instanceof Person){
        persons[index].introduce()
      }else{
        console.log("All items in array must be Person class instances.")
        return
      }
    }
  }
}
const firstPerson = new Person("Chika", "mark", 50)
const secondPerson = new Person("Peter", "Joshua", 40)
const thirdPerson = new Person("Clement", "Joe", 90)
const help = 5;
let arr = [firstPerson, secondPerson, thirdPerson, help]
Person.introducePeople(arr)
const num = 0
Person.introducePeople(num)
/****************************************************************************/
/******************* DO NOT EDIT CODE BELOW THIS LINE ***********************/

try {
  module.exports = Person;
} catch {
  module.exports = null;
}