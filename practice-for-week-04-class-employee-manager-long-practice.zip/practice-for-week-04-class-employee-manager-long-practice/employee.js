class Employee{
    constructor(name, salary, title, manager){
        this.name = name;
        this.salary = salary;
        this.title = title
        this.manager = manager || null

        if (manager != null){
            manager.addEmployee(this)
        }
    }

    calculateBonus(multiplier){
        let bonus = this.salary * multiplier
        return bonus
    }
}
//const man = new Employee("Chika", 90000, "Supervisor", "works")
//console.log(man)

module.exports = Employee