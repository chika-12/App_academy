function isFive(num) {
  if (num == 5){
    return true
  }else{
    return false
  }
  // Your code here
}

function isOdd(number) {
  if (typeof number == "number"){
    if(number % 2 == 0){
      return false
    }else{
      return true
    } 
  }else{
    throw new Error("Error")
  }
  // Your code here
}

function myRange(min, max, step = 1) {
  if (min > max){
    return []
  }
  let arr = [];
  for(let index = min; index <= max; index += step){
    arr.push(index)
  }
  return arr
  // Your code here
}


module.exports = { isFive, isOdd, myRange };