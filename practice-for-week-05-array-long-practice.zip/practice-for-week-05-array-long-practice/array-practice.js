const findMinimum = arr => {
  let small = arr[0]
  arr.forEach(num=>{
    if (num < small){
      small = num
    }
  })
  return small
  // Your code here
};

const runningSum = arr => {
  let arr2 = []
  if(arr === null){
    return []
  }
  for(let index = 0; index < arr.length; index += 1){
    if (index == 0){
      arr2.push(arr[index])
    }else{
      num = arr[index] + arr2[index - 1]
      arr2.push(num)
    }
  }
  return arr2
  // Your code here
};

const evenNumOfChars = arr => {
  if(arr.length === null){
    return 0
  }
  let count = 0;
  for(let index = 0; index < arr.length; index++){
    if(arr[index].length % 2 == 0){
      count += 1;
    }
  }
  return count
  // Your code here
};

const smallerThanCurr = arr => {
  let valCount = [];
  let count = 0; 
  for(let index = 0; index < arr.length; index++){
    for(let idx = 0; idx < arr.length; idx++){
      if(arr[index ]> arr[idx]){
        count += 1
      }
    }
    valCount.push(count);
    count = 0;
  } 
  return valCount
  // Your code here
};

const twoSum = (arr, target) => {
  for(let index = 0; index < arr.length; index++){
    for(let idx = 0; idx < arr.length; idx++){
      if(arr[index] + arr[idx] === target){
        return true
      }
    }
  }
  return false
  // Your code here
};

const secondLargest = arr => {
  let sorted = false; 
  while (!sorted){
    sorted = true
    for(let index = 0; index < arr.length; index++){
      if(arr[index] > arr[index + 1]){
        let num = arr[index]
        arr[index] = arr[index + 1]
        arr[index + 1] = num
        sorted = false 
      }
    }
  }
  return arr[arr.length - 2]
};

const shuffle = (arr) => {
  let newArr = []
  let index = []
  while (newArr.length < arr.length){
    let num = Math.floor(Math.random() * arr.length)
    if(!index.includes(num)){
      newArr.push(arr[num]);
      index.push(num)
    }
  }
  return newArr;
  // Your code here
};


module.exports = [findMinimum, runningSum, evenNumOfChars, smallerThanCurr, twoSum, secondLargest, shuffle];