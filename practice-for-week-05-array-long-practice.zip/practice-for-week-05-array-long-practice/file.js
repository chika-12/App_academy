const shuffle = (arr) => {
  let newArr = []
  let index = []
  while (newArr.length < arr.length){
    let num = Math.floor(Math.random() * arr.length)
    if(!index.includes(num)){
      newArr.push(arr[num]);
      index.push(num)
    }
  }
  return newArr;
  // Your code here
};
console.log(shuffle([1,2,3,4,5,6,7]))