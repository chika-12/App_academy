The Alien Invasion game is built by pontex lab tech team 
it is purely for entertainment purpose.

    This project started on 2nd of june 2024
    and is to be completed on 7th of june 2024
    Version: alien_invasion_x1

                                    The Alien Invasion Game
    This game is about shooting down ships perceived to be alien ships your goal is to make sure you take 
    down all ships with limited number of ships available to you and the challenge increases as you progress.
    You can adjust the settings file to your specification. 
    But other files remain untouched. Adjustment to other files should
    only be done  by a professional. only values in settings should be adjusted.
    NB. Variable names should not be changed as this may lead to malfunctioning of 
        the software application.


    Usage: You can lunch the game by typing from your terminal 
                python3 alien_invasion.py or python alien_invasion.py
                depending on the python interpreter installed on your system.
                Use the space bar key to shoot down ships and the arrow keys to navigate
    Note : This game is automated to run on fullscreen mode so adjustment to screen_width
                and height in settings might not work you can check for other versions of the game that
                allows for user screen manipulations from pontex lab: Soon to be released
                Owing to the fact that the game is fullscreen automated you 
                have to press "q" on your keyboard to quit as this is the only way to close 
                the python window that will be automatically created  by lunching this game.

    This file will be updated................................ 