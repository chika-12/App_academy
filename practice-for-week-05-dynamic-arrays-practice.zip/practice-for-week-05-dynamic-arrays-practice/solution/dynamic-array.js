class DynamicArray {

  constructor(defaultSize=4) {
    this.defaultSize = defaultSize;
    this.capacity = defaultSize
    this.data = new Array(this.capacity)
    this.length = 0
    // Your code here
  }

  read(index) {
    return this.data[index]
    // Your code here
  }

  unshift(val) {
    if(this.length === this.capacity){
      this.resize()
    }
    for(let index = this.length; index > 0; index -= 1){
      this.data[index] = this.data[index - 1]
    }
    this.data[0] = val
    this.length += 1;
    return this.length
  }
  resize(){
    this.capacity *= 2;
    let newData = new Array(this.capacity);

    for(let index = 0; index < this.length; index += 1){
      newData[index] = this.data[index]
    }
    this.data = newData;
  }
}
const num = new DynamicArray()
console.log(num.data)
console.log(num.length)
num.unshift(6)
console.log(num.data)
console.log(num.length)


module.exports = DynamicArray;