const chai = require("chai")
const expect = chai.expect
const spies = require("chai-spies")
const myMap = require("../problems/my-map")
chai.use(spies)

describe("My map", function(){
    let arr;
    beforeEach(function(){
        arr = [1,2,3];
    })
    it("it should return a new array", function(){  
        let callback = (num)=> num * 2;
        const result = myMap(arr, callback);
        expect(result).to.deep.equal([2,4,6]); 
    });

    it("should call myMap function for each element", function(){
        //const arr = [1,2,3];
        const callback = chai.spy((num)=>num * 2);
        myMap(arr, callback)
        expect(callback).to.have.been.called.exactly(3)
    });

    it("should call the callback with each element in the array", function(){
        //const arr = [1,2,3];
        const callback = chai.spy((num)=> num * 2);
        myMap(arr, callback);
        expect(callback).to.have.been.called.with(1);
        expect(callback).to.have.been.called.with(2);
        expect(callback).to.have.been.called.with(3);
    });
    it("it should not mutate the original array", function(){
        const newArr = [...arr];
        const callback = (num)=> num * 2;
        myMap(arr, callback)
        expect(newArr).to.deep.equal(arr)
    });
    it("it should not call the built in array.map function", function(){
        const callback = chai.spy((num)=> num * 2);
        //const originalMap = Array.prototype.map;
        Array.prototype.map = chai.spy()
        myMap(arr, callback);
        expect(Array.prototype.map).not.to.have.been.called;
        //Array.prototype.map = originalMap;
    });
})