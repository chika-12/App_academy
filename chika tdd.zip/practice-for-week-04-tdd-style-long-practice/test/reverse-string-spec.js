const chai = require("chai")
const expect = chai.expect
const reverseString = require("../problems/reverse-string")


describe("String reverse", function(){
    it("it should reverse a string", function(){
        let str = reverseString("fun")
        expect(str).to.equal('nuf')
    })
    context("if input is not a string", function(){
        it("it should throw an error",function(){
            expect(()=>reverseString(67)).to.throw("Input must be a string");
        })
    })
})