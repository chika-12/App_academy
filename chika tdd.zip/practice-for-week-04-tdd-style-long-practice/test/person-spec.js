const chai = require("chai")
const expect = chai.expect
const spies = require("chai-spies")
const Person = require("../problems/person")
chai.use(spies)// Your code here

describe("Person", function(){
    let newPerson;
    let arr = [];
    beforeEach(function(){
        newPerson = new Person("chika", 45)
        arr = [new Person("chika",32), new Person("mark", 45), new Person("peter", 23)];

        arr.forEach(person=> chai.spy.on(person, "sayHello"))
    });
    it("should create instance of a class when called", function(){
       expect(newPerson).to.exist 
    });
    it("name exist", function(){
        expect(newPerson.name).to.equal("chika")
    });
    it("age exit", function(){
        expect(newPerson.age).to.equal(45);
    });
    it("say hello instance method",function(){
        expect(newPerson.sayHello()).to.equal("Hello chika")
    })
    it("first instance name visited second instance", function(){
        const secondTest = new Person("mark", 23);
        expect(secondTest.visited(newPerson)).to.equal("mark visited chika")
    });
    it("it should invoke the visit instance method", function(){
        const thirdTest = new Person("peter", 21);
        expect(thirdTest.switchVisit(newPerson)).to.equal("chika visited peter")
    });
    context("update(obj) instance method",function(){
        it("it shold throw an error if object is not a valid instance", function(){
            expect(()=> newPerson.update("people")).to.throw (TypeError, "Must be a valid instance")
        });

        it("it should not throw an error if an error if object is a valid instance",function(){
            const person1 = new Person("mary", 34)
            expect(()=> newPerson.update(person1)).to.not.throw();
            newPerson.update(person1)
            expect(newPerson.name).to.equal("mary");
            expect(newPerson.age).to.equal(34)
        });
        it("incoming object should have name and age",function(){
            const person3 = new Person(undefined, 34)
            const person4 = new Person("chika", undefined)
            expect(()=> newPerson.update(person3)).to.throw(Error, "name is required")
            expect(()=> newPerson.update(person4)).to.throw(Error, "age is required")
        })
    });
    context("tryUpdate method",function(){
        it("it should correctly call the update method", function(){
            const person1 = new Person("chika", 23)
            const person2 = new Person(undefined, 23)
            const person3 = new Person("chika", undefined)
            expect(newPerson.tryUpdate(person1)).to.equal(true)
            expect(newPerson.tryUpdate(person2)).to.equal(false)
            expect(newPerson.tryUpdate(person3)).to.equal(false)

        })
    });
    context("greetAll(obj)",function(){
        it("it should take an array of names", function(){
            let str = ""
            expect(()=>Person.greetAll(str)).to.throw(TypeError,"input must be an array")
        })
        it("it should loop through the array and call sayHello instance method", function(){
            const greetings = Person.greetAll(arr)
            arr.forEach(person=>{
                expect(person.sayHello).to.have.been.called.once;
            })
            expect(greetings).to.be.an("array")
            expect(greetings).to.deep.equal(["Hello chika", "Hello mark", "Hello peter"]);
        });
    });

});