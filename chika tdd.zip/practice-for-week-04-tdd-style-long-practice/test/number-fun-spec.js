const chai = require("chai")
const expect = chai.expect
const {returnsThree, reciprocal} = require("../problems/number-fun")

describe("Return three", function(){
    it("should return three", function(){
        const num = returnsThree();
        expect(num).to.equal(3)
    });
});

describe("Reciprocal", function(){
    context("if valid argument", function(){
        it("it should find the reciprocal of a number", function(){
            const num = reciprocal(4);
            const num2 = reciprocal(2.88)
            const num3 = reciprocal(8)
            expect(num).to.equal(0.25)
            expect(num2).to.equal(0.3472222222222222 )
            expect(num3).to.equal(0.125)
        })
    })

    context("if number is less than 1 or greater than 1000000", function(){
        it("it should throw an error", function(){
            expect(()=>reciprocal(0)).to.throw("value should be >= 1 and not > 1000000")
            expect(()=>reciprocal(-1)).to.throw("value should be >= 1 and not > 1000000")
            expect(()=> reciprocal(1000200)).to.throw("value should be >= 1 and not > 1000000")
        })
    })
})