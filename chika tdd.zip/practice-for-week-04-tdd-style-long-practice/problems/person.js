class Person {
  constructor(name, age){
    this.name = name;
    this.age = age;
  }
  // Your code here
  sayHello(){
    return `Hello ${this.name}`
  }
  visited(otherName){
    return `${this.name} visited ${otherName.name}`
  }
  switchVisit(otherName){
    return otherName.visited(this)
  }
  update(obj){
    if (!(obj instanceof Person)){
      throw new TypeError("Must be a valid instance")

    }else if(obj.name === undefined){
      throw new Error("name is required")

    }else if (obj.age === undefined){
      throw new Error("age is required")

    }else{
      this.name = obj.name;
      this.age = obj.age;
    }
  }
  tryUpdate(obj){
    try{
      this.update(obj);
      return true

    }catch (error){
      return false
    }
  }
  static greetAll(obj){
    
    if (!(Array.isArray(obj))){
      throw new TypeError("input must be an array")
    }
    const arr = obj.map(person=> {
      if(!(person instanceof Person)){
        throw new Error("must be an instance of Person")
      }else{
        return person.sayHello()
      }
    })
    return arr;
  }
}

module.exports = Person;