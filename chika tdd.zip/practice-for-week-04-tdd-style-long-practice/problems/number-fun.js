function returnsThree() {
  return 3
  // Your code here
}

function reciprocal(n) {
  // Your code here
  if( n < 1 || n > 1000000){
    throw new Error("value should be >= 1 and not > 1000000")
  }
  return 1/n
}

module.exports = {
  returnsThree,
  reciprocal
};