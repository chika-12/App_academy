function myMap(inputArray, callback) {
  let result = [];
  for(let index = 0; index < inputArray.length; index += 1){
    result.push(callback(inputArray[index], index, inputArray));
  }
  return result
}

module.exports = myMap;