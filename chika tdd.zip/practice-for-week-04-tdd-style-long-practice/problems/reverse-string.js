module.exports = function reverseString(string) {
  if (typeof string !== "string"){
    throw new Error("Input must be a string")
  }
  let str ="";
  for(let index = string.length - 1; index >= 0; index -= 1){
    str += string[index]
  }
  return str
  // Your code here
};